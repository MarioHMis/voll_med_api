package med.voll.api.domain.consulta.validaciones;

import med.voll.api.domain.consulta.DatosReservaConsulta;

public interface ValidadorDeConsultas {
    void validar(DatosReservaConsulta daots);
}
