package med.voll.api.domain.usuarios;

public record DatosAutenticacionUsuario(String login, String clave) {
}
