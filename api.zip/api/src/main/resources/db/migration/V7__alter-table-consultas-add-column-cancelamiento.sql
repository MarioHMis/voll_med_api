alter table consultas add column motivo_cancelamiento varchar(100);
